/***************************************************************************/
/*                                                                         */
/* This file is only a wrapper for C++ Builder, where a project cannot     */
/* contain a source file with the same base name as the project itself.    */
/* for other Windows build environments, please use slptool.c directly.    */
/*                                                                         */
/***************************************************************************/

#include "../../slptool/slptool.c"
#pragma link "slp.lib"
