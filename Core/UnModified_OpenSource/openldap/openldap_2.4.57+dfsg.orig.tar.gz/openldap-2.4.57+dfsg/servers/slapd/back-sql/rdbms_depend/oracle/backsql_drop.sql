drop table ldap_attr_mappings;
drop table ldap_entry_objclasses;
drop table ldap_referrals;
drop sequence ldap_entry_ids;
drop sequence ldap_attr_ids;
drop sequence ldap_objclass_ids;
drop table ldap_entries;
drop table ldap_oc_mappings;
