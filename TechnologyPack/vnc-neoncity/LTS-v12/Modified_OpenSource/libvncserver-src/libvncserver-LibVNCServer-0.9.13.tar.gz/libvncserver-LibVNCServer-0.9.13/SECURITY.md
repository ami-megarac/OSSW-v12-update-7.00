# Security Policy

## Supported Versions

We fix security problems on the master branch. Downstream packagers are
advised to cherry-pick those onto release versions. Currently, no point
releases of already-released versions are made due to low development
team head count.

## Reporting a Vulnerability

Mail in to dontmind@sdf.org.
